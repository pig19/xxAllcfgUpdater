import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class xxAllUpdaterG3A2 {
    public static void main(String[] args) {
        String inputFileName = "BlockAndItemWithMetaNames.txt";
        String mineallConfigFileName = "..\\config\\net.minecraft.scalar.mineall.mod_mineallsmp.cfg";
        String cutallConfigFileName = "..\\config\\net.minecraft.scalar.cutall.mod_cutallsmp.cfg";

        // Update config settings
        updateConfigSetting(mineallConfigFileName, "S:blockIds=", "S:blockIds=");
        updateConfigSetting(mineallConfigFileName, "S:itemIds=", "S:itemIds=");
        updateConfigSetting(cutallConfigFileName, "S:blockIds=", "S:blockIds=");
        updateConfigSetting(cutallConfigFileName, "S:itemIds=", "S:itemIds=");
        updateConfigSetting(cutallConfigFileName, "S:leaveIds=", "S:leaveIds=");
                


        List<String> ore = new ArrayList<>();
        List<String> pick = new ArrayList<>();
        List<String> log = new ArrayList<>();
        List<String> axe = new ArrayList<>();
        List<String> leave = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                for (String part : parts) {
                    if (part.contains(":ore") || part.contains("_ore")) {
                        ore.add(part);
                    } else if (part.contains("pick")) {
                        pick.add(part);
                    } else if (part.contains(":log") || part.contains("_log")) {
                        log.add(part);
                    } else if (part.contains("_axe")) {
                        axe.add(part);
                    } else if (part.contains(":leave") || part.contains("_leave")) {
                        leave.add(part);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Update mineallConfigFileName
        updateConfigFile(mineallConfigFileName, "S:blockIds=", ore);
        updateConfigFile(mineallConfigFileName, "S:itemIds=", pick);

        // Update cutallConfigFileName
        updateConfigFile(cutallConfigFileName, "S:blockIds=", log);
        updateConfigFile(cutallConfigFileName, "S:itemIds=", axe);
        updateConfigFile(cutallConfigFileName, "S:leaveIds=", leave);
    }

    private static void updateConfigFile(String fileName, String configName, List<String> items) {
        try {
            BufferedReader file = new BufferedReader(new FileReader(fileName));
            String line;
            String input = "";

            while ((line = file.readLine()) != null) {
                if (line.startsWith(configName)) {
                    line += " " + String.join(", ", items);
                }
                input += line + '\n';
            }

            file.close();

            BufferedWriter output = new BufferedWriter(new FileWriter(fileName));
            output.write(input);
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void updateConfigSetting(String fileName, String search, String replace) {
        try {
            BufferedReader file = new BufferedReader(new FileReader(fileName));
            String line;
            String input = "";

            while ((line = file.readLine()) != null) {
                if (line.contains(search)) {
                    line = replace;
                }
                input += line + '\n';
            }

            file.close();

            BufferedWriter output = new BufferedWriter(new FileWriter(fileName));
            output.write(input);
            output.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
